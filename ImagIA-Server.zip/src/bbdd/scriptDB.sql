CREATE DATABASE ImagIAdb;

CREATE USER 'ImagIAuser'@'localhost' IDENTIFIED BY 'ImagIAp@ss123';

GRANT ALL PRIVILEGES ON ImagIAdb.* TO 'ImagIAuser'@'localhost';

FLUSH PRIVILEGES;